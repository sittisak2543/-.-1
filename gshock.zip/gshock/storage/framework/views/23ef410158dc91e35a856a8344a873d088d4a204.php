
<?php $__env->startSection('title'); ?> BikeShop | แก้ไขข้อมูลสินค้า <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
    <?php echo Form::model($faculty, array('action' => 'FacultyController@update','method' => 'post', 'enctype' => 'multipart/form-data')); ?>

    <input type="hidden" name="id" value="<?php echo e($faculty->id); ?>">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    

    <div class="panel-heading">
        <div class="panel-title"><strong>ข้อมูลสินค้า</strong></div>
    </div>
    <div class="panel-body">
        <table>
        
            <tr>
                <td><?php echo e(Form::label('name_th', 'ชื่อสินค้า')); ?></td>
                <td><?php echo e(Form::text('name_th', Request::old('name_th'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('name_en', 'ชื่อสินค้า')); ?></td>
                <td><?php echo e(Form::text('name_en', Request::old('name_en'), ['class' => 'form-control'])); ?></td>
            </tr>
        </table>
    </div>
    <div class="panel-footer">
      <button type="reset" class="btn btn-danger">ยกเลิก</button>
      <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> บันทึก</button>
    </div>
    <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\PP\work\gshock\resources\views/faculty/edit.blade.php ENDPATH**/ ?>