<?php

use Illuminate\Database\Seeder;

class PersonTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('person')->insert(array(

            [
            
            'firstname' => 'Nakamichi NMCE110-BK',   
            'lastname' => 'Nakamichi NMCE110-BK',   

            
            ],
                        
            ));           
    }
}