<?php

use Illuminate\Database\Seeder;

class FacultyTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('faculty')->insert(array(

            [
            
            'name_th' => 'Nakamichi NMCE110-BK',   
            'name_en' => 'Nakamichi NMCE110-BK',   

            
            ],
                        
            ));           
    }
}