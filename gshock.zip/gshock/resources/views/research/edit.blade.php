@extends("layouts.master")
@section('title') BikeShop | แก้ไขข้อมูลสินค้า @stop
@section('content')
<div class="panel panel-default">
    {!! Form::model($research, array('action' => 'ResearchController@update','method' => 'post', 'enctype' => 'multipart/form-data')) !!}
    <input type="hidden" name="id" value="{{ $research->id }}">
    @if($errors->any())
    <div class="alert alert-danger">
        @foreach ($errors->all() as $error)<div>{{ $error }}</div>@endforeach
    </div>
    @endif
    

    <div class="panel-heading">
        <div class="panel-title"><strong>ข้อมูลสินค้า</strong></div>
    </div>
    <div class="panel-body">
        <table>
        
            <tr>
                <td>{{ Form::label('name_th', 'ชื่อสินค้า') }}</td>
                <td>{{ Form::text('name_th', Request::old('name_th'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('name_en', 'ชื่อสินค้า') }}</td>
                <td>{{ Form::text('name_en', Request::old('name_en'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('budget', 'ชื่อสินค้า') }}</td>
                <td>{{ Form::text('budget', Request::old('budget'), ['class' => 'form-control']) }}</td>
            </tr>
        </table>
    </div>
    <div class="panel-footer">
      <button type="reset" class="btn btn-danger">ยกเลิก</button>
      <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> บันทึก</button>
    </div>
    {!! Form::close() !!}
</div>

@stop
