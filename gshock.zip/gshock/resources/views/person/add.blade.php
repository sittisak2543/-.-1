@extends("layouts.master")
@section('title') BikeShop | เพิ่มข้อมูลสินค้า @stop
@section('content')
<div class="panel panel-default">
    {!! Form::open(array('action' => 'PersonController@insert', 'method'=>'post', 'enctype' => 'multipart/form-data')) !!}

    @if($errors->any())
    <div class="alert alert-danger">
        @foreach ($errors->all() as $error)<div>{{ $error }}</div>@endforeach
    </div>
    @endif

    <div class="panel-heading">
        <div class="panel-title"><h3>เพิ่มข้อมูลสินค้า</h3></div>
    </div>
    <div class="panel-body">
        <table>
            <tr>
                <td>{{ Form::label('firstname', 'ชื่อสินค้า') }}</td>
                <td>{{ Form::text('firstname', Request::old('firstname'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('lastname', 'ชื่อสินค้า') }}</td>
                <td>{{ Form::text('lastname', Request::old('lastname'), ['class' => 'form-control']) }}</td>
            </tr>
        </table>
    </div>
    <div class="panel-footer">
      <button type="reset" class="btn btn-danger">ยกเลิก</button>
      <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> บันทึก</button>
    </div>
    {!! Form::close() !!}
</div>


@stop
