@extends("layouts.master")
@section('title') PPShop | ร้านขายนาฬิกาออนไลน์ @stop
@section('content')
<h1>รายการสินค้า</h1>
<ul class="breadcrumb">
    <li><a href="#">หน้าแรก </a>&nbsp;</li>
    <li class="active">รายการสินค้า</li>
</ul>
<div class="panel panel-default">
    <div class="panel-body">
        <a href="{{ URL::to('person/edit') }}" class="btn btn-success pull-right"><i class="fa fa-plus"></i> เพิ่มข้อมูล</a>
        <form action="{{ URL::to('person/search') }}" method="post" class="form-inline">
            {{ csrf_field() }}
            <input type="text" name="q" class="form-control" placeholder="พิมพ์ชื่อสินค้าเพื่อค้นหา">
            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> ค้นหา</button>
        </form>


     
    </div>
    <table class="table table-bordered table-striped table-hover">
    
        <thead>
        <br />
        <tr>
        
            <th>ชื่อภาษาไทย</th>
            <th>ชื่อภาษาอังกฤษ</th>

        </tr>

        </thead>
        
        <tbody>
            @foreach($persons as $p)
            <tr>

                <td>{{ $p->firstname }}</td>
                <td>{{ $p->lastname }}</td>
                <td>
                
                    <a href="{{ URL::to('person/edit/'.$p->id) }}" class="btn btn-info"><i class="fa fa-pencil"></i></a>
                    <a href="#" class="btn btn-danger btn-delete" id-delete="{{ $p->id }}"><i class="fa fa-trash-o"></i> ลบ</a>
                </td>
                <script>
                    $('.btn-delete').on('click', function() {
                        if(confirm("คุณต้องการลบข้อมูลสินค้าหรือไม่?")) {
                            var url = "{{ URL::to('person/remove') }}" + '/' + $(this).attr('id-delete');
                            window.location.href = url;
                        }
                    });
                </script>
            </tr>
            
            @endforeach
        </tbody>
    </table>
    

    {{ $persons->links() }}

</div>

@stop
