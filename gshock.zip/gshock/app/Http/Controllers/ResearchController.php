<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Research;
use App\Category;

class ResearchController extends Controller
{
    var $rp = 2;

    public function index() {
        $researchs = Research::paginate($this->rp);
        return view('research/index', compact('researchs'));
    }
    public function edit($id = null) {
        $categories = Category::pluck('name', 'id')->prepend('เลือกรายการ', '');
        if($id) {
            $research = research::where('id', $id)->first();
            return view('research/edit')
                ->with('research', $research)
                ->with('categories', $categories);
        } else {
            return view('research/add')
                ->with('categories', $categories);
        }
    
    }
    public function update(Request $request) {
        $rules = array(
            'name_th' => 'required',
            'name_en' => 'required',
            'budget' => 'required',

        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $id = $request->input('id');
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('research/edit/'.$id)
                ->withErrors($validator)
                ->withInput();
        }
        $research = research::find($id);
        $research->name_th = $request->input('name_th');
        $research->name_en = $request->input('name_en');
        $research->budget = $request->input('budget');
        $research->save();
        return redirect('research')
            ->with('ok', true)
            ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
    
    }
    public function insert(Request $request) {
        $rules = array(
            'name_th' => 'required',
            'name_en' => 'required',
            'budget' => 'required',
        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('research/edit')
                ->withErrors($validator)
                ->withInput();
        }
        $research = new research();
        $research->name_th = $request->input('name_th');
        $research->name_en = $request->input('name_en');
        $research->budget = $request->input('budget');
        $research->save();
        return redirect('research')
            ->with('ok', true)
            ->with('msg', 'เพิ่มข้อมูลเรียบร้อยแล้ว');
    }
    

 
    public function search(Request $request) {
        $query = $request->input('q');
        if($query) {
            $researchs = research::where('name_th', 'like', '%'.$query.'%')
                ->orWhere('firstname', 'like', '%'.$query.'%')
                ->paginate($this->rp);

        } else {
            $researchs = research::paginate($this->rp);
        }
        return view('research/index', compact('researchs'));

    }

    public function remove($id) {
        research::find($id)->delete();
        return redirect('research')
            ->with('ok', true)
            ->with('msg', 'ลบข้อมูลสำเร็จ');
    }
    
    
    
    
    
}
