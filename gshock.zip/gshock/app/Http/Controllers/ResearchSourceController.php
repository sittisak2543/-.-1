<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\ResearchSource;
use App\Category;

class ResearchSourceController extends Controller
{
    var $rp = 2;

    public function index() {
        $researchSources = ResearchSource::paginate($this->rp);
        return view('researchSource/index', compact('researchSources'));
    }
    public function edit($id = null) {
        $categories = Category::pluck('name', 'id')->prepend('เลือกรายการ', '');
        if($id) {
            $researchSource = researchSource::where('id', $id)->first();
            return view('researchSource/edit')
                ->with('researchSource', $researchSource)
                ->with('categories', $categories);
        } else {
            return view('researchSource/add')
                ->with('categories', $categories);
        }
    
    }
    public function update(Request $request) {
        $rules = array(
            'name' => 'required',


        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $id = $request->input('id');
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('researchSource/edit/'.$id)
                ->withErrors($validator)
                ->withInput();
        }
        $researchSource = researchSource::find($id);
        $researchSource->name = $request->input('name');

        $researchSource->save();
        return redirect('researchSource')
            ->with('ok', true)
            ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
    
    }
    public function insert(Request $request) {
        $rules = array(
            'name' => 'required',

        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('researchSource/edit')
                ->withErrors($validator)
                ->withInput();
        }
        $researchSource = new researchSource();
        $researchSource->name = $request->input('name');

        $researchSource->save();
        return redirect('researchSource')
            ->with('ok', true)
            ->with('msg', 'เพิ่มข้อมูลเรียบร้อยแล้ว');
    }
    

 
    public function search(Request $request) {
        $query = $request->input('q');
        if($query) {
            $researchSources = researchSource::where('name', 'like', '%'.$query.'%')
                ->orWhere('name', 'like', '%'.$query.'%')
                ->paginate($this->rp);

        } else {
            $researchSources = researchSource::paginate($this->rp);
        }
        return view('researchSource/index', compact('researchSources'));

    }

    public function remove($id) {
        researchSource::find($id)->delete();
        return redirect('researchSource')
            ->with('ok', true)
            ->with('msg', 'ลบข้อมูลสำเร็จ');
    }
    
    
    
    
    
}
