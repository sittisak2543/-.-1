<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Person;
use App\Category;

class PersonController extends Controller
{
    var $rp = 2;

    public function index() {
        $persons = Person::paginate($this->rp);
        return view('person/index', compact('persons'));
    }
    public function edit($id = null) {
        $categories = Category::pluck('name', 'id')->prepend('เลือกรายการ', '');
        if($id) {
            $person = person::where('id', $id)->first();
            return view('person/edit')
                ->with('person', $person)
                ->with('categories', $categories);
        } else {
            return view('person/add')
                ->with('categories', $categories);
        }
    
    }
    public function update(Request $request) {
        $rules = array(
            'firstname' => 'required',
            'lastname' => 'required',

        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $id = $request->input('id');
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('person/edit/'.$id)
                ->withErrors($validator)
                ->withInput();
        }
        $person = person::find($id);
        $person->firstname = $request->input('firstname');
        $person->lastname = $request->input('lastname');
        $person->save();
        return redirect('person')
            ->with('ok', true)
            ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
    
    }
    public function insert(Request $request) {
        $rules = array(
            'firstname' => 'required',
            'lastname' => 'required',
        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('person/edit')
                ->withErrors($validator)
                ->withInput();
        }
        $person = new person();
        $person->firstname = $request->input('firstname');
        $person->lastname = $request->input('lastname');
        $person->save();
        return redirect('person')
            ->with('ok', true)
            ->with('msg', 'เพิ่มข้อมูลเรียบร้อยแล้ว');
    }
    

 
    public function search(Request $request) {
        $query = $request->input('q');
        if($query) {
            $persons = person::where('firstname', 'like', '%'.$query.'%')
                ->orWhere('firstname', 'like', '%'.$query.'%')
                ->paginate($this->rp);

        } else {
            $persons = person::paginate($this->rp);
        }
        return view('person/index', compact('persons'));

    }

    public function remove($id) {
        person::find($id)->delete();
        return redirect('person')
            ->with('ok', true)
            ->with('msg', 'ลบข้อมูลสำเร็จ');
    }
    
    
    
    
    
}
