<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResearchSource extends Model
{
    protected $table = 'researchSource';
    public function category() {
        return $this->belongsTo('App\Category');
    }

}
