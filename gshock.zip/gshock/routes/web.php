<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
##faculty
Route::get('/faculty', 'FacultyController@index');
Route::post('/faculty/search', 'FacultyController@search');
Route::get('/faculty/search', 'FacultyController@search');
Route::get('/faculty/edit/{id?}', 'FacultyController@edit');
Route::post('/faculty/update', 'FacultyController@update');
Route::post('/faculty/insert', 'FacultyController@insert');
Route::get('/faculty/remove/{id}', 'FacultyController@remove');

##person
Route::get('/person', 'PersonController@index');
Route::post('/person/search', 'PersonController@search');
Route::get('/person/search', 'PersonController@search');
Route::get('/person/edit/{id?}', 'PersonController@edit');
Route::post('/person/update', 'PersonController@update');
Route::post('/person/insert', 'PersonController@insert');
Route::get('/person/remove/{id}', 'PersonController@remove');

##research
Route::get('/research', 'ResearchController@index');
Route::post('/research/search', 'ResearchController@search');
Route::get('/research/search', 'ResearchController@search');
Route::get('/research/edit/{id?}', 'ResearchController@edit');
Route::post('/research/update', 'ResearchController@update');
Route::post('/research/insert', 'ResearchController@insert');
Route::get('/research/remove/{id}', 'ResearchController@remove');

##researchSource
Route::get('/researchSource', 'ResearchSourceController@index');
Route::post('/researchSource/search', 'ResearchSourceController@search');
Route::get('/researchSource/search', 'ResearchSourceController@search');
Route::get('/researchSource/edit/{id?}', 'ResearchSourceController@edit');
Route::post('/researchSource/update', 'ResearchSourceController@update');
Route::post('/researchSource/insert', 'ResearchSourceController@insert');
Route::get('/researchSource/remove/{id}', 'ResearchSourceController@remove');


